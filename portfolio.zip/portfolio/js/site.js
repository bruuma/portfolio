function myFunction() {
    document.getElementsByClassName("topnav")[0].classList.toggle("responsive");
};

$(document).ready(function() {
 
			  $("#owl-demo").owlCarousel({
					
				  autoPlay: true,
				  pagination: true,
				  slideSpeed : 300,
				  paginationSpeed : 400,
				  singleItem:true

			 
			  });
			 
});

$('.filter a').click(function(e) {
  e.preventDefault();
  var a = $(this).attr('href');
  a = a.substr(1);
  $('.gallery a').each(function() {
    if (!$(this).hasClass(a) && a != 'all')
      $(this).addClass('hide');
    else
      $(this).removeClass('hide');
  });

});

$('.gallery a').click(function(e) {
  e.preventDefault();
  var $i = $(this);
  $('.gallery a').not($i).toggleClass('pophide');
  $i.toggleClass('pop');
});


  