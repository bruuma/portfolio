<?php
if(isset($_POST['enviar']) && !empty($_POST)){

@$nome = $_POST['nome'];
@$email = $_POST['email'];
@$assunto = $_POST['assunto'];
@$mensagem = $_POST['mensagem'];

if(empty($nome) || empty($email) || empty($assunto) || empty($mensagem)){
	echo "<script>window.location.href='http://www.brunamcampos.com.br';</script>";
	exit();
}


	$to = 'brunamcampos@outlook.com.br'; // Seu email


			$html .= "Nome : " . $nome ."      /" ;
			$html .= "Assunto : " . $assunto ."      /" ;
			$html .= "E-mail : " . $email ."      /";

		
		$html .= "Mensagem: " . $mensagem ;
		

		
	@$envia_email = mail($to, $assunto, $html);

	if(@$envia_email){
		echo "<script>alert('E-mail enviado com sucesso');</script>";
	}else{
		echo "<script>alert('Erro. Tente Novamente mais tarde');</script>";
	}

	echo "<script>window.location.href='http://www.brunamcampos.com.br';</script>";
}else{
	echo "<script>window.location.href='http://www.brunamcampos.com.br';</script>";
}
?>

